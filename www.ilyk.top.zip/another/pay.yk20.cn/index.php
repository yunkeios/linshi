<!DOCTYPE html>
<html>

<meta name="viewport" content="width=device-width,height=device-height,inital-scale=1.0,maximum-scale=1.0,user-scalable=no;">
 <meta name="apple-mobile-web-app-capable" content="yes">
 <meta name="apple-mobile-web-app-status-bar-style" content="black">
 <meta name="format-detection" content="telephone=no">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"

//主体部分
<head>
    <title>在线支付</title>
</head>
<body>
    <h1>向云科科技付款</h1>

    <?php
    // 网址列表
    $websites = array(
        array('名称' => '微信支付1(推荐)', '链接' => '/wx1.png'),
        array('名称' => '微信支付2', '链接' => '/wx2.png'),
        array('名称' => '微信支付3(备用)', '链接' => '/wx3.png'),
        array('名称' => '云科官网', '链接' => 'https://yk20.cn'),
        // 添加更多网站...
    );

    // 遍历网址列表并生成链接
    foreach ($websites as $website) {
        echo '<a href="' . $website['链接'] . '">' . $website['名称'] . '</a><br>';
    }
    ?>

</body>
</html>