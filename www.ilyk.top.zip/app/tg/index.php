<?php
header("HTTP/1.1 301 Moved Permanently");
header("Location: https://t.me/+UNbLHS7ByV5kNmM1");
exit();
?>