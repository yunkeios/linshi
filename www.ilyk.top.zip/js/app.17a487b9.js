import {
	_ as d,
	o as p,
	c as l,
	V as u,
	a5 as o,
	Q as i,
	a6 as m,
	a7 as _,
	a8 as v,
	a9 as b,
	aa as f,
	ab as g,
	ac as h,
	ad as y,
	ae as A,
	af as w,
	M as P,
	d as x,
	u as C,
	p as E,
	k as R,
	ag as D,
	ah as L,
	ai as S
} from "./chunks/framework.af1bb881.js";
import {
	t as r
} from "./chunks/theme.0c647bdd.js";
const T = "/imgs/screen1.png",
	V = "/imgs/screen2.png",
	k = "/imgs/screen3.png",
	O = "/imgs/screen4.png",
	j = "/imgs/screen5.png";
const B = {},
	F = {
		class: "home-preview-block"
	},
	H = u(
		'<div class="home-preview" data-v-b50b3de2><h2 data-v-b50b3de2>截图预览</h2><div class="items" data-v-b50b3de2><div class="item" data-v-b50b3de2><img data-fancybox="gallery" src="' +
		T + '" data-v-b50b3de2></div><div class="item" data-v-b50b3de2><img data-fancybox="gallery" src="' + V +
		'" data-v-b50b3de2></div><div class="item" data-v-b50b3de2><img data-fancybox="gallery" src="' + k +
		'" data-v-b50b3de2></div><div class="item" data-v-b50b3de2><img data-fancybox="gallery" src="' + O +
		'" data-v-b50b3de2></div><div class="item" data-v-b50b3de2><img data-fancybox="gallery" src="' + j +
		'" data-v-b50b3de2></div></div></div>', 1),
	I = [H];

function $(e, a) {
	return p(), l("div", F, I)
}
const M = d(B, [
		["render", $],
		["__scopeId", "data-v-b50b3de2"]
	]),
	N = {
		...r,
		Layout() {
			return o(r.Layout, null, {
				"home-features-after": () => o(M)
			})
		}
	};

function c(e) {
	if (e.extends) {
		const a = c(e.extends);
		return {
			...a,
			...e,
			async enhanceApp(t) {
				a.enhanceApp && await a.enhanceApp(t), e.enhanceApp && await e.enhanceApp(t)
			}
		}
	}
	return e
}
const s = c(N),
	G = x({
		name: "VitePressApp",
		setup() {
			const {
				site: e
			} = C();
			return E(() => {
				R(() => {
					document.documentElement.lang = e.value.lang, document.documentElement.dir = e
						.value.dir
				})
			}), D(), L(), S(), s.setup && s.setup(), () => o(s.Layout)
		}
	});
async function Q() {
	const e = q(),
		a = U();
	a.provide(_, e);
	const t = v(e.route);
	return a.provide(b, t), a.component("Content", f), a.component("ClientOnly", g), Object.defineProperties(a
		.config.globalProperties, {
			$frontmatter: {
				get() {
					return t.frontmatter.value
				}
			},
			$params: {
				get() {
					return t.page.value.params
				}
			}
		}), s.enhanceApp && await s.enhanceApp({
		app: a,
		router: e,
		siteData: h
	}), {
		app: a,
		router: e,
		data: t
	}
}

function U() {
	return y(G)
}

function q() {
	let e = i,
		a;
	return A(t => {
		let n = w(t);
		return e && (a = n), (e || a === n) && (n = n.replace(/\.js$/, ".lean.js")), i && (e = !1), P(() =>
			import(n), [])
	}, s.NotFound)
}
i && Q().then(({
	app: e,
	router: a,
	data: t
}) => {
	a.go().then(() => {
		m(a.route, t.site), e.mount("#app")
	})
});
export {
	Q as createApp
};