<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <script>
        // 获取设备信息
        function getDeviceInfo() {
            const userAgent = navigator.userAgent;
            let device = "Unknown Device";

            if (/mobile/i.test(userAgent)) {
                device = "Mobile";
            } else if (/iPad|Android|Touch/.test(userAgent)) {
                device = "Tablet";
            } else {
                device = "Desktop";
            }

            return device;
        }

        // 获取当前时间
        function getCurrentTime() {
            return new Date().toLocaleString();
        }

        // 通过JavaScript将设备信息和时间发送给PHP脚本
        const deviceInfo = getDeviceInfo();
        const currentTime = getCurrentTime();

        fetch('get_info.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ deviceInfo: deviceInfo, currentTime: currentTime })
        })
        .then(response => response.text())
        .then(data => console.log(data))
        .catch(error => console.error('Error:', error));
    </script>
</body>
</html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lyk在线时间</title>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background: linear-gradient(135deg, #ff7e5f, #feb47b);
            font-family: 'Arial', sans-serif;
        }
        .clock {
            color: #fff;
            font-size: 60px;
            text-align: center;
            background: rgba(0, 0, 0, 0.2);
            padding: 20px 40px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
        }
    </style>
</head>
<body>
    <div class="clock" id="clock">加载中...</div>
    <script>
        async function fetchBeijingTime() {
            try {
                const response = await fetch('https://worldtimeapi.org/api/timezone/Asia/Shanghai');
                const data = await response.json();
                return new Date(data.datetime);
            } catch (error) {
                console.error('无法获取北京时间:', error);
                return new Date();
            }
        }

        function updateClock() {
            const now = new Date();
            const hours = String(now.getHours()).padStart(2, '0');
            const minutes = String(now.getMinutes()).padStart(2, '0');
            const seconds = String(now.getSeconds()).padStart(2, '0');
            document.getElementById('clock').textContent = `${hours}:${minutes}:${seconds}`;
        }

        async function startClock() {
            const beijingTime = await fetchBeijingTime();
            setInterval(() => {
                beijingTime.setSeconds(beijingTime.getSeconds() + 1);
                const hours = String(beijingTime.getHours()).padStart(2, '0');
                const minutes = String(beijingTime.getMinutes()).padStart(2, '0');
                const seconds = String(beijingTime.getSeconds()).padStart(2, '0');
                document.getElementById('clock').textContent = `${hours}:${minutes}:${seconds}`;
            }, 1000);
        }

        startClock();
    </script>
</body>
</html>