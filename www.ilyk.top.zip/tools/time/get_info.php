<?php
// 获取用户IP地址
$ip_address = $_SERVER['REMOTE_ADDR'];

// 获取POST请求中的设备信息和当前时间
$post_data = json_decode(file_get_contents('php://input'), true);
$device_info = $post_data['deviceInfo'];
$current_time = $post_data['currentTime'];

// 设置保存信息的文件路径
$file = 'user_info.txt';

// 拼接保存的内容
$data = "Time: $current_time, IP Address: $ip_address, Device: $device_info" . PHP_EOL;

// 打开文件并写入信息
file_put_contents($file, $data, FILE_APPEND | LOCK_EX);

echo "信息已保存: $data";
?>