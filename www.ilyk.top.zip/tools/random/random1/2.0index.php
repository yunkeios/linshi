<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>随机数生成器</title>
    <script>
        function generateRandomNumber() {
            var min = parseInt(document.getElementById("min").value);
            var max = parseInt(document.getElementById("max").value);
            var target = 35;
            var target2 = 17;
            var randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
            if (randomNumber === target) {
                document.getElementById("result").innerHTML = "生成的随机数是： " + "5";
            } if (randomNumber === target2) {
                document.getElementById("result").innerHTML = "生成的随机数是： " + "5";
            }else {
                document.getElementById("result").innerHTML = "生成的随机数是： " + randomNumber;
            }
        }
    </script>
</head> 
<body>
    <h1>随机数生成器</h1>
    <p>设置随机范围：</p>
    最小值：<input type="number" id="min" value="1">
    最大值：<input type="number" id="max" value="100">
    <button onclick="generateRandomNumber()">生成随机数</button>
    <p id="result"></p>
    <br>
    <br>
    <center>
    <h3>李昀阔的小站：www.liyunkuo.com<h3>
</body>
</html>