
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>随机数生成器</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
        }
        input[type="file"] {
            display: block;
            margin: 0 auto;
        }
        button {
            display: block;
            margin: 20px auto;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        #result {
            text-align: center;
            font-size: 24px;
            font-weight: bold;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Excel表格中随机抽取</h1>
        <center>
        <h3>Lyk官网：www.ilyk.top<h3>
        <input type="file" id="fileInput" accept=".xlsx,.xls">
        <button onclick="generateRandomNumber()">生成随机数</button>
        <div id="result"></div>
    </div>
    <script>
        function generateRandomNumber() {
            const fileInput = document.getElementById('fileInput');
            const result = document.getElementById('result');
            const file = fileInput.files[0];
            if (!file) {
                result.textContent = '请选择一个Excel文件';
                return;
            }
            const reader = new FileReader();
            reader.onload = function (e) {
                const data = e.target.result;
                const workbook = XLSX.read(data, { type: 'binary' });
                const sheetName = workbook.SheetNames[0];
                const sheet = workbook.Sheets[sheetName];
                const range = XLSX.utils.decode_range(sheet['!ref']);
                const row = Math.floor(Math.random() * (range.e.r - range.s.r + 1)) + range.s.r;
                const cell = Math.floor(Math.random() * (range.e.c - range.s.c + 1)) + range.s.c;
                const cellAddress = XLSX.utils.encode_cell({ c: cell, r: row });
                const cellValue = sheet[cellAddress].v;
                result.textContent = cellValue;
            };
            reader.readAsBinaryString(file);
        }
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.0/xlsx.full.min.js"></script>
    <br><center>
    <h3>上传Excel要求：
    Excel有多少个格就会随机多少个格<br>
    所以如果想随机一列的话把其余的列全部删掉！
    <br><br>
    如图所示：
    </h3>
    <div class="msg_desc">
<img style="max-width:100%;overflow:hidden;" src="https://p1.meituan.net/csc/66e98a1d6db0f6bbd910f932fe0fc47373673.jpg" alt="">
</div>
</body>
</html>
