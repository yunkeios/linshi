<?php
return array (
  'switch' => true,
  'title' => '官方公告',
  'msg_switch' => true,
  'version' => 'v1.9.5',
  'update_msg' => '<li class=\'list-group-item\'><b>六零导航页v1.9.5</b> </li><li class=\'list-group-item\'><a class=\'btn btn-success btn-w-md\' href=\'./update.php\' >更新</a></li>',
  'update_log' => '<li class=\'list-group-item\'><strong>更新 版本号为1.9.5</strong></li></li><li class=\'list-group-item\'>增加 部分主题增加主题独立设置</li><li class=\'list-group-item\'>增加 部分主题支持方向键选择搜索词</li><li class=\'list-group-item\'>增加 部分主题支持今日热搜显示(后台-主题设置-主题自定义设置)</li><li class=\'list-group-item\'>增加 详情页模式</li><li class=\'list-group-item\'>增加 收录页支持批量操作</li><li class=\'list-group-item\'>增加 内网部署的支持</li><li class=\'list-group-item\'>优化 部分主题显示效果</li><li class=\'list-group-item\'>优化 安装程序，增加提示</li><li class=\'list-group-item\'>优化 优化代码结构</li><li class=\'list-group-item\'>安全 增加网站防火墙，修复木马上传</li><li class=\'list-group-item\'>移除 天气显示插件因服务停止移除</li><li class=\'list-group-item\'>授权 未授权站点功能将受限，支持离线授权，内网IP免授权</li><li class=\'list-group-item\'>其他 PHP版本需7.1及以上（不支持PHP8）</li>',
  'file' => 'https://cdn.lylme.com/lylme_spage/releases/lylme_spage_v1.9.5_update.zip',
  'msg' => '<li class=\'list-group-item\'><font color=\'green\'><i class=\'mdi mdi-cloud-check\'></i> 站点授权状态：【正版授权】[yuan.iosyk.com]</font></li><li class=\'list-group-item\'>六零导航页QQ交流群：933434961</li><li class=\'list-group-item\'>非常感谢热心网友们对本开源项目的赞助和支持 <a href=\'https://www.lylme.com/support/\' target=\'_blank\'>查看名单</a></li>',
  'd' => 'C5FA26EFEEED2EA2',
  'domain' => 'yuan.iosyk.com',
)
?>