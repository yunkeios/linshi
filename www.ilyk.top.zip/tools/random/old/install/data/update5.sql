-- v1.2.0
INSERT INTO `lylme_tags` (`tag_id`, `tag_name`, `tag_link`, `tag_target`) VALUES (NULL, '关于本站', '/about', '1');