<html> <head> 
<meta name="viewport" content="width=device-width,height=device-height,inital-scale=1.0,maximum-scale=1.0,user-scalable=no;">
 
 <meta name="apple-mobile-web-app-capable" content="yes">
 
 <meta name="apple-mobile-web-app-status-bar-style" content="black">
 
 <meta name="format-detection" content="telephone=no"><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> <title>Lyk在线听歌</title> <frameset framespacing="0" border="0" rows="0" frameborder="0"> <frame name="main" src="http://box.flac.ltd/" scrolling="auto" noresize></frameset> </head> <body></body> </html>